﻿string input = Console.ReadLine();

foreach (var c in input)
{
    Console.WriteLine(c);
}