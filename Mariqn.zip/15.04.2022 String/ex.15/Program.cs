﻿string[] input = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

Console.WriteLine($"{input[0][0]}.{input[1][0]}.{input[2][0]}");