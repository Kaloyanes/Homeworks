﻿string[] input = Console.ReadLine().Trim().Split();

Console.WriteLine(input.Length);