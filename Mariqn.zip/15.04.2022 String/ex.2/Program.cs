﻿char[] input = Console.ReadLine().ToCharArray();
Array.Reverse(input);
Console.WriteLine(new string(input));