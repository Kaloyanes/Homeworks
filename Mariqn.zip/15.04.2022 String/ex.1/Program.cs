﻿string input = Console.ReadLine();
Console.WriteLine(input);
